# Covid-Track-v2

#### Application using HTMl, CSS and JS and have it compiled using Cordova after.
